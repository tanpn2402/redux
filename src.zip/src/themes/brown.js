export default {
  title: 'brown',
  buttonClicked: {
    backgroundColor: "#8B7765",
    color: "#FFFACD"
  },
  pagebackground: {
    backgroundColor: '#f5f5f5',

  }
}